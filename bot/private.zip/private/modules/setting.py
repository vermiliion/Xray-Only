from private import *
import subprocess
from telethon import events

@bot.on(events.CallbackQuery(data=b'reboot'))
async def rebooot(event):
	async def rebooot_(event):
		await event.edit("`Loading......`")
		cmd = f'reboot'
		
		subprocess.check_output(cmd, shell=True)
		await event.edit(f"""
**» REBOOT SERVER**
**» 🤖@LITE_VERMILION**"""
    ,buttons=[[Button.inline("‹ 𝗠𝗮𝗶𝗻 𝗠𝗲𝗻𝘂 ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await rebooot_(event)
	else:
		await event.answer("Buy Premium Chat: @Lite_Vermilion",alert=True)


@bot.on(events.CallbackQuery(data=b'resx'))
async def rebooot(event):
    async def rebooot_(event):
        cmd = 'bot-restart'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception:
            await event.respond(f"**Successfully Restarted Service**")
        else:
            await event.respond(
                f"""
**» SUCCESSFULLY RESTARTED SERVICE**
**» 🤖@LITE_VERMILION**
""",
                buttons=[[Button.inline("‹ 𝗠𝗮𝗶𝗻 𝗠𝗲𝗻𝘂 ›", "menu")]]
            )
    
    sender = await event.get_sender()
    user_id = str(sender.id)
    if valid(user_id) == "true":
        await rebooot_(event)
    else:
        await event.answer("Buy Premium Chat: @Lite_Vermilion", alert=True)
        

@bot.on(events.CallbackQuery(data=b'speedtest'))
async def speedtest(event):
	async def speedtest_(event):
		await event.edit("`Loading......`")
		cmd = 'speedtest-cli --share'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")

		await event.respond(f"""
**
{z}
**
**» 🤖@LITE_VERMILION**
""",buttons=[[Button.inline("‹ 𝗠𝗮𝗶𝗻 𝗠𝗲𝗻𝘂 ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await speedtest_(event)
	else:
		await event.answer("Buy Premium Chat: @Lite_Vermilion",alert=True)

@bot.on(events.CallbackQuery(data=b'backup'))
async def backup(event):
    user_id = str(event.sender_id)

    async def backup_(event):
        async with bot.conversation(event.chat_id) as user:
            await event.respond('**Input Email :**')
            user_input = await user.wait_event(events.NewMessage(incoming=True, from_users=event.sender_id))
            email = user_input.raw_text
        await event.edit("`Loading......`")
        
        # Enclose the email in single quotes to handle any special characters
        cmd = f'printf "%s\n" "{email}" | bot-backup'
        
        try:
            backup_output = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT).decode("utf-8")
        except subprocess.CalledProcessError as e:
            await event.respond(f"**Backup failed with error:**\n```{e.output.decode('utf-8')}```")
        else:
            msg = f"""```{backup_output}```
**🤖@LITE_VERMILION**"""
            await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    
    # Validate user permission
    a = valid(str(sender.id))
    if a == "true":
        await backup_(event)
    else:
        await event.answer("Buy Premium Chat: @Lite_Vermilion", alert=True)

@bot.on(events.CallbackQuery(data=b'restore'))
async def restore(event):
    async def restore_(event):
        async with bot.conversation(event.chat_id) as user:
            await event.respond('**Input Link Backup :**')
            user_input = await user.wait_event(events.NewMessage(incoming=True, from_users=event.sender_id))
            backup_link = user_input.raw_text
        await event.edit("`Loading......`")
        cmd = f'printf "%s\n" "{backup_link}" | bot-restore'
        try:
            restore_output = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except subprocess.CalledProcessError:
            await event.respond("**Link Not Exist**")
        else:
            msg = f"""```{restore_output}```
**🤖@LITE_VERMILION**"""
            await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    
    # Validate user permission
    a = valid(str(sender.id))
    if a == "true":
        await restore_(event)
    else:
        await event.answer("Buy Premium Chat: @Lite_Vermilion", alert=True)
        
		
@bot.on(events.CallbackQuery(data=b'backer'))
async def backers(event):
	async def backers_(event):
		inline = [
[Button.inline("𝗕𝗮𝗰𝗸𝘂𝗽","backup"),
Button.inline("𝗥𝗲𝘀𝘁𝗼𝗿𝗲","restore")],
[Button.inline("‹ 𝗠𝗮𝗶𝗻 𝗠𝗲𝗻𝘂 ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
**◇⟨MENU BACKUP & RESTORE⟩◇**
**◇━━━━━━━━━━━━━━━━━◇**
** » Domain:** `{DOMAIN}`
** » ISP:** `{z["isp"]}`
** » Region:** `{z["country"]}`
**🤖 »**@LITE_VERMILION
**◇━━━━━━━━━━━━━━━━━◇**
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await backers_(event)
	else:
		await event.answer("Buy Premium Chat: @Lite_Vermilion",alert=True)

@bot.on(events.CallbackQuery(data=b'setting'))
async def settings(event):
	async def settings_(event):
		inline = [
[Button.inline("𝗕𝗮𝗰𝗸𝘂𝗽 & 𝗥𝗲𝘀𝘁𝗼𝗿𝗲","backer")],
[Button.inline("𝗦𝗽𝗲𝗲𝗱𝘁𝗲𝘀𝘁","speedtest")],
[Button.inline("𝗥𝗲𝘀𝘁𝗮𝗿𝘁 𝗦𝗲𝗿𝘃𝗶𝗰𝗲","resx"),
Button.inline("𝗥𝗲𝗯𝗼𝗼𝘁 𝗦𝗲𝗿𝘃𝗲𝗿","reboot")],
[Button.inline("‹ 𝗠𝗮𝗶𝗻 𝗠𝗲𝗻𝘂 ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
       **◇⟨MENU SETTINGS⟩◇**
**◇━━━━━━━━━━━━━━━━━◇**
** » Domain:** `{DOMAIN}`
** » ISP:** `{z["isp"]}`
** » Region:** `{z["country"]}`
**🤖 »**@LITE_VERMILION
**◇━━━━━━━━━━━━━━━━━◇**
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await settings_(event)
	else:
		await event.answer("Buy Premium Chat: @Lite_Vermilion",alert=True)
